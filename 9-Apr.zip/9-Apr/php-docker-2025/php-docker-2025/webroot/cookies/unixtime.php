<?php
$unixtime = time();
echo $unixtime;