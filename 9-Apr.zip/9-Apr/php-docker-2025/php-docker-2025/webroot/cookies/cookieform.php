<html lang="en">
<head>
 <meta charset="UTF-8">
 <title>Cookie form</title>
</head>
<body>
<form action="setcookie.php" method="post">
    Name: <input type="text" name="name"><br>
    Password: <input type="password" name="password"><br>
 <input type="submit" value="Submit">
 <input type="reset" value="Reset">
</form>
</body>
</html>