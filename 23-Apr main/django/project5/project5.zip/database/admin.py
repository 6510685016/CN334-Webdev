from django.contrib import admin
from database.models import Person

# Register your models here.
admin.site.register(Person)