<?php

require $persons = 'data.inc.php';
require 'persons2.view.php';

//var_dump($persons);
